import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class WalletScreen extends StatelessWidget {
  const WalletScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();

    return Scaffold(
      appBar: AppBar(
        title: const Text('BRD Wallet'),
      ),
      body: const Center(
        child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text(
          'Welcome to BRD Wallet!\nTransactions and balances will appear here.',
          textAlign: TextAlign.center,
          ),
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: () async {
              const AndroidNotificationDetails androidPlatformChannelSpecifics = AndroidNotificationDetails(
                'brd_channel_id', 'BRD Notifications',
                importance: Importance.max,
                priority: Priority.high,
              );
              const NotificationDetails platformChannelSpecifics = NotificationDetails(android: androidPlatformChannelSpecifics);
              await flutterLocalNotificationsPlugin.show(
                0,
                'BRD Wallet',
                'تم استلام مبلغ 25 USDT',
                platformChannelSpecifics,
              );
            },
            child: const Text('تجربة إشعار'),
          )
        ],
      ),
    );
  }
}
